import java.util.Scanner;
import java.util.Random;



class Main {

  //method for greeting the player

  static void greeting(){

    System.out.println("\nWHAT IS THE BEST NUMBER?\n");
    System.out.println("Code Written By: Tyler Grady\n");
    System.out.println("Code inspired and Theorized By: Ben Sparks at Numberphile\n");
    System.out.println("Original Video Found Here:\n https://www.youtube.com/watch?v=ULhRLGzoXQ0&ab_channel=Numberphile\n\n");
    System.out.println("This code was written in order to prove a theory about a simple bar game known as farkle or its more common name, dice game. This theory states that in this game, the best number to aim for to consistently win is 20. More accurately in the video, Ben Sparks actually says any number below 20 is safe. However, they go with 20 so thats what this code will be simulating. The math for finding this numerical expression is in the original video.\n\nThe rules for the game are as follows:\n\n");
  }

  //method for displaying the rules of the game

  static void rules(){

    System.out.println("1. Player1 (Thats you), will input a score they wish to aim for during each round of this game.\n");
    System.out.println("2. Each player rolls the dice until they hit the number total for that round that they input.\n");
    System.out.println("3. After each roll, the player will add their score to the total ammount of points earned by them in that round.\n");
    System.out.println("4. If a player rolls a one (AKA a Brick in farkle), that players total points for that round are forfeited and the players turn ends.\n");
    System.out.println("5. In this version of the game we are doing 25 simulated rounds and whichever player has the highest score by the end of round 25 will be declared the winner.");
  }

  //method to change score before start

  static void finale(){

    System.out.println("\nThis is your last chance to change the score your aiming for each round before the game starts");

    System.out.println("\nIf you wish to change your score please press 1 and enter, if you are content with your score press 2 and enter to continue to the game.");
  }


  public static void main(String[] args) {

    greeting(); //greeting the player

    rules(); //rules for game for player

    //variables for score and player score
    int correctScore = 0;
    int plyrNum = 0;
    boolean isNumber;

    //loop for changing score and asking for player score

    do{

      System.out.println("\n\nPlease choose the numerical value you wish to aim for during your turns this game (EX: 5, 7, 13):");

      Scanner scanner = new Scanner(System.in);

      //do while getting and verifying user data

      do{
        //if else statement for verifying user score
        if(scanner.hasNextInt()){

          plyrNum = scanner.nextInt();
          isNumber = true;
        }

        else{

          System.out.println("Please enter a numerical value\n");
          isNumber = false;
          scanner.next();
        }

      }while(!(isNumber));

      System.out.println("\nIf you wish to change your score from " + plyrNum + ", please press one then enter. If you are happy with your score, please select 2 then enter to continue.\n");
      //another do while to verify selection for changing the score
      do{

        if(scanner.hasNextInt()){

          correctScore = scanner.nextInt();
          isNumber = true;          
        }

        else{

          System.out.println("Please enter a numerical value\n");
          isNumber = false;
          scanner.next();
        }

      }while(!(isNumber));



      

      


    }while(correctScore == 1);
      

      

    //if statement that is activated once score is settled

    if(correctScore == 2){

      System.out.println("\nGood luck! Lets see if you can beat 20\n");
    }

    //variables for game

    int counter, counter2 = 0, counter3 = 0;
    int total1 = 0, total2 = 0;
    int roundScore1 = 0, roundScore2 = 0;
    int brick = 0, brick2 = 0;
    int result = 0, result2 = 0;
    int twenty = 20;
    //variable for randomizing dice rolls
    Random r = new Random();

   
  
    //for loop to act as dice

    for(counter = 1; counter <= 25; counter++){
      //annoucing each round
      System.out.println("Round: " + counter + "\n");
      //do while loop while player score != 1
      do{

        result = r.nextInt(5);
        result++;

        System.out.println("Your roll was equal to: " + result);
        //if a roll is 1 this if statement subtracts the round total and breaks the loop
        if(result == 1){

          brick++;
          System.out.println("Your total number of bricks is equal to: " + brick + "\n");

          result = 0;
          total1 -= counter2;
          roundScore1 = 0;


          break;

        }
        //adding up score and total
        roundScore1 = result;

        counter2 += result;

        result = 0;

        total1 += roundScore1;
        //displaying total
        System.out.println("Your total score is: " + total1 + "\n");

        

      }while(plyrNum > counter2);
      //announcement to know whose turn it is
      System.out.println("It's 20's turn, get ready!\n");

      System.out.println("******************************************************\n");

      

      //reset the variables for keeping track of score and loop
      roundScore1 = 0;
      counter2 = 0;
      //do while loop for 20
      do{

        result2 = r.nextInt(5);
        result2++;

        System.out.println("20's roll was equal to: " + result2);
        //to break the loop if a 20 rolls a 1
        if(result2 == 1){

          brick2++;
          System.out.println("20's total number of bricks is equal to: " + brick2 + "\n");

          result2 = 0;
          total2 -= counter3;
          roundScore2 = 0;


          break;

        }
        //adding up 20's score
        roundScore2 = result2;

        counter3 += result2;

        result2 = 0;

        total2 += roundScore2;
        //announcing 20's score
        System.out.println("20's total score is: " + total2 + "\n");

        

      }while(twenty > counter3);

      //reset the counting variables for round and loop
      roundScore2 = 0;
      counter3 = 0;
      //if statement to get rid of this statement at the end of the game
      if(counter == 1 || counter == 24){

        System.out.println("It's players turn, get ready!\n");

      }
      
    }
    //announcement if player1 wins
    if(total1 > total2){

      System.out.println("\nCongratulations Player1, your number, "+ plyrNum + "; was victorius over the number 20!\n");

      System.out.println("Your total Score: "+ total1);
      System.out.println("20's total Score: "+ total2);
 
    }
    //announcement if player1 loses
    else if(total1 < total2){

      System.out.println("\nAnother player falls at the feet of the superior number 20, it's ok, not everyone can be victorius.\n");

      System.out.println("Your total Score: "+ total1);
      System.out.println("20's total Score: "+ total2);
    }
    //announcement if scores tie
    else if(total1 == total2){

      System.out.println("\nIt looks like " + plyrNum + "; is just as great as the number 20!\n");

      System.out.println("Your total Score: "+ total1);
      System.out.println("20's total Score: "+ total2);
    }
    //displaying the results for player1 in the simulation
    System.out.println("\nYour stats from this game are as follows:");
    System.out.println("\n--------------------------------------------\n");
    System.out.println("Chosen Number: " + plyrNum + "\n");
    System.out.println("Total Score: "+ total1 + "\n");
    System.out.println("Total Bricks/1's: "+ brick);

 
  }
}
      
    

    